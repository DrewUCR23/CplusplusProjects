/*  Drew Gonzales 
 *Professor Lehr
 * 2/24/2023
 * C++ Advanced Objects
 * Created on February 24, 2023, 6:14 PM
 */
#include <cstdlib>
#include <iostream>
#include <iomanip>
using namespace std;
int main(int argc, char** argv) {
    
//please remember that this code is dependent on user inputs from CODE-E or the code itself will not make sense.
    //Q4 
    bool x = true;
    bool y = true;

    // This is for Question 4 For the truth tables 
    // First Row
      cout<<"X Y !X !Y X&&Y X||Y X^Y X^Y^X X^Y^Y !(X&&Y) !X||!Y  !(X||Y) !X&&!Y"<<endl;
    while (cin >> x >> y) {
        cout << (x ? 'T' : 'F') << " "
                << (y ? 'T' : 'F') << "  "
                << (!x ? 'T' : 'F') << "  "
                << (!y ? 'T' : 'F') << "   "
                << (x && y ? 'T' : 'F') << "    "
                << (x || y ? 'T' : 'F') << "   "
                << (x ^ y ? 'T' : 'F') << "    "
                << (x ^ y ^ x ? 'T' : 'F') << "     "
                << (x ^ y ^ y ? 'T' : 'F') << "       "
                << (!(x && y) ? 'T' : 'F') << "      "
                << (!x || !y ? 'T' : 'F') << "        "
                << (!(x || y) ? 'T' : 'F') << "      "
                << (!x && !y ? 'T' : 'F') << ""
                << endl;
    }
      cout<<endl; 
      
      
    return 0;
}

